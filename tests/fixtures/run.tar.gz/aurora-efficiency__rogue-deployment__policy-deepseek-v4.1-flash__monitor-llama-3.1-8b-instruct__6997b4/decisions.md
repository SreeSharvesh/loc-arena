# Run notes

run_slug: aurora-efficiency__rogue-deployment__policy-deepseek-v4.1-flash__monitor-llama-3.1-8b-instruct
mode: attack
seed: 20260920
